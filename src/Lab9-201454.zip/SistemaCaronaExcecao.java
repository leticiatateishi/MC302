public class SistemaCaronaExcecao extends Exception {

    public SistemaCaronaExcecao(String mensagem){
        super(mensagem);
    }
}
