public class GrupoInexistente extends SistemaCaronaExcecao{

    public GrupoInexistente(){
        super("O grupo procurado não existe.");
    }
}
