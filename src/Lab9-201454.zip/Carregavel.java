public interface Carregavel{
    void carregarParaArquivo();
}
