public interface Salvavel {
    void salvarParaArquivo();
}
