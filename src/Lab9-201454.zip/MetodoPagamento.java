enum MetodoPagamento {
    CARTAODECREDITO,
    DINHEIRO,
    GRATIS;
}
